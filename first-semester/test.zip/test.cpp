#include<iostream>
#include<iomanip>
using namespace std;

int main(){
	int a = 8, b = 4;
	int sub, mul, div, add;
	
	cout<<"The sum is = "<<add<<endl;
	cout<<"The subtraction is = "<<sub<<endl;
	cout<<"The multiplication is = "<<mul<<endl;
	cout<<"The division is = "<<div;



	return 0;

	


	// //First question
	// cout<<"*\n";
	// cout<<"* *\n";
	// cout<<"* * *\n";
	// cout<<"* * * *";
	
	//second question

	// cout<<"*"<<setw(6)<<"*"<<endl;
	// cout<<setw(2)<<"*"<<setw(4)<<"*"<<endl;
	// cout<<setw(4)<<"*"<<endl;
	// cout<<setw(2)<<"*"<<setw(4)<<"*"<<endl;
	// cout<<"*"<<setw(6)<<"*"<<endl;
	

  //third question

//   cout<<"********"<<endl;
//   cout<<"********"<<endl;
//   cout<<"********"<<endl;
//   cout<<"********"<<endl;
//   cout<<"********";


}